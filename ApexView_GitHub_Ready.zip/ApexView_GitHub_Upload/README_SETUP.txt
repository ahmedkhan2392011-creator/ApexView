ApexView GitHub Pages upload

1. Extract this ZIP.
2. Upload index.html and ApexView_1_7.apk directly into the root of your GitHub repository (not inside another folder).
3. Commit the files.
4. In GitHub repository Settings > Pages, choose Deploy from a branch, select main and /(root), then Save.

The website's two APK download buttons link to ./ApexView_1_7.apk and use the download attribute. The APK must remain beside index.html in the published folder.
