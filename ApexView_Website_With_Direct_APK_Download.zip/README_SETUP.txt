APEXVIEW WEBSITE SETUP

1. Upload index.html and ApexView_1_7.apk to the same folder on your website hosting.
2. Open your website's index.html page.
3. The Download for Android and Download APK buttons link directly to ./ApexView_1_7.apk and request a file download.

Note: The Continue with Google button in this HTML redirects to AhmedView_Pro_Paper_Trading.html. That separate file is not included in this package. The button is not Google authentication.
